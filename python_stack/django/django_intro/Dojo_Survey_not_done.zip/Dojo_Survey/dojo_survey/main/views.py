from django.shortcuts import render, redirect

# Create your views here.
def index(request):
    return render(request, 'index.html')

def results(request):
    # print(request.POST)
    # print(request.POST['name'])
    # context={
    #     'name': request.POST["name"],
    #     'dojo_location' : request.POST["dojo_location"],
    #     'favorite_language': request.POST["favorite_language"],
    #     'comment': request.POST["comment"]
    # }
    name = request.POST["name"]
    dojo_location = request.POST["dojo_location"]
    # return render(request, 'results.html', context)
    return redirect(f'/success/{name}', f'/success/{dojo_location}')

def direct_to_index(request):
    return redirect('/')

def success(request, name, dojo_location):
    context = {
        "name_from_form": name,
        "dojo_location_from_form": dojo_location,
}
    return render(request, 'results.html', context)


